==============
qvm-open-in-vm
==============

NAME
====
qvm-open-in-vm - open a specified file in other VM

:Date:   2012-05-30

SYNOPSIS
========
| qvm-open-in-vm vmname filename

OPTIONS
=======

AUTHORS
=======
| Joanna Rutkowska <joanna at invisiblethingslab dot com>
| Rafal Wojtczuk <rafal at invisiblethingslab dot com>
| Marek Marczykowski <marmarek at invisiblethingslab dot com>
