#!/bin/sh

# Prevents QT from displaying ugly QT theme
if [ -z "$GNOME_DESKTOP_SESSION_ID" ]; then
    export GNOME_DESKTOP_SESSION_ID="${XDG_SESSION_ID}"
fi
