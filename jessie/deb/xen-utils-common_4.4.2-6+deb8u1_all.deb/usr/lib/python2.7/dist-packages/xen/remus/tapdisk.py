import blkdev

class TapDisk(BlkDev):
    pass
