void gui_fatal(const char *fmt, ...);
void gui_nonfatal(const char *fmt, ...);
