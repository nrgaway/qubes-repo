# Stops QT from using the MIT-SHM X11 Shared Memory Extension
export QT_X11_NO_MITSHM=1
