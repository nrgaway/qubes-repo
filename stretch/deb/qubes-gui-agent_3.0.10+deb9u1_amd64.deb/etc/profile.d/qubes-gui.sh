export DISPLAY=:0
