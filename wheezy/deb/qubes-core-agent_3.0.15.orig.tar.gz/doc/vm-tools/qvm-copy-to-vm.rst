==============
qvm-copy-to-vm
==============

NAME
====
qvm-copy-to-vm - copy specified files to specified destination VM

:Date:   2012-05-30

SYNOPSIS
========
| qvm-copy-to-vm [--without-progress] dest_vmname file [file]+

OPTIONS
=======
--without-progress
    Don't display progress info

AUTHORS
=======
| Joanna Rutkowska <joanna at invisiblethingslab dot com>
| Rafal Wojtczuk <rafal at invisiblethingslab dot com>
| Marek Marczykowski <marmarek at invisiblethingslab dot com>
