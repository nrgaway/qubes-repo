===============
qvm-open-in-dvm
===============

NAME
====
qvm-open-in-dvm - open a specified file in disposable VM

:Date:   2012-05-30

SYNOPSIS
========
| qvm-open-in-dvm filename

OPTIONS
=======

AUTHORS
=======
| Joanna Rutkowska <joanna at invisiblethingslab dot com>
| Rafal Wojtczuk <rafal at invisiblethingslab dot com>
| Marek Marczykowski <marmarek at invisiblethingslab dot com>
