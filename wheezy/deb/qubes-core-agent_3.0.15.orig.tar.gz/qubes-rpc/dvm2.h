#define DVM_FILENAME_SIZE 256
#define DVM_SPOOL "/home/user/.dvmspool"
