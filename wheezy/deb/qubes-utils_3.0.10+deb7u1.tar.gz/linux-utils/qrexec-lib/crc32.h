#ifndef _CRC32_H
#define _CRC32_H

extern unsigned long Crc32_ComputeBuf( unsigned long inCrc32, const void *buf,
        size_t bufLen );

#endif /* _CRC32_H */
